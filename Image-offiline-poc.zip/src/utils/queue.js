import localforage from "localforage";

const QUEUE_KEY = "uploadQueue";

export const addToQueue = async (item) => {
  const queue = (await localforage.getItem(QUEUE_KEY)) || [];
  queue.push(item);
  await localforage.setItem(QUEUE_KEY, queue);
};

export const getQueue = async () => {
  return (await localforage.getItem(QUEUE_KEY)) || [];
};

export const clearQueue = async () => {
  await localforage.removeItem(QUEUE_KEY);
};

export const processQueue = async () => {
  const queue = await getQueue();

  for (let item of queue) {
    try {
      await fetch(item.url, {
        method: item.method,
        body: item.body,
      });
    } catch (err) {
      console.log("Retry failed", err);
      return;
    }
  }

  await clearQueue();
};