import React, { useState } from "react";
import imageCompression from "browser-image-compression";

// Helper: get dimensions
const getImageDimensions = (file) => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    img.onload = () => {
      resolve({
        width: img.width,
        height: img.height,
      });
    };
  });
};

// Helper: format size
const formatSize = (bytes) => {
  return (bytes / 1024 / 1024).toFixed(2) + " MB";
};

export default function ImageCompressor() {
  const [results, setResults] = useState([]);
  const [original, setOriginal] = useState(null);
  const [originalInfo, setOriginalInfo] = useState(null);

  const [convertToJpeg, setConvertToJpeg] = useState(true);
  const [resizeEnabled, setResizeEnabled] = useState(true);

  const qualityLevels = [0.9, 0.7, 0.5, 0.3];

  const handleImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setResults([]);

    const originalURL = URL.createObjectURL(file);
    setOriginal(originalURL);

    const originalDim = await getImageDimensions(file);

    setOriginalInfo({
      size: formatSize(file.size),
      dim: originalDim,
      type: file.type,
    });

    const tempResults = [];

    for (let quality of qualityLevels) {
      const start = performance.now();

      const compressedFile = await imageCompression(file, {
        maxWidthOrHeight: resizeEnabled ? 1280 : undefined,
        initialQuality: quality,
        useWebWorker: true,
        fileType: convertToJpeg ? "image/jpeg" : file.type,
      });

      const compressedDim = await getImageDimensions(compressedFile);

      const end = performance.now();

      const savings = (
        ((file.size - compressedFile.size) / file.size) *
        100
      ).toFixed(2);

      tempResults.push({
        quality: Math.round(quality * 100),
        url: URL.createObjectURL(compressedFile),
        size: formatSize(compressedFile.size),
        dim: compressedDim,
        type: compressedFile.type,
        savings,
        time: (end - start).toFixed(0),
      });
    }

    setResults(tempResults);
  };

  return (
    <div style={{ padding: 20 }}>
      {/* <h2>Advanced Image Compression POC</h2> */}

      {/* Toggles */}
      <label style={{ display: "block", marginBottom: 10 }}>
        <input
          type="checkbox"
          checked={convertToJpeg}
          onChange={(e) => setConvertToJpeg(e.target.checked)}
        />
        Convert to JPEG (Recommended)
      </label>

      <label style={{ display: "block", marginBottom: 10 }}>
        <input
          type="checkbox"
          checked={resizeEnabled}
          onChange={(e) => setResizeEnabled(e.target.checked)}
        />
        Resize to 1280px (Recommended)
      </label>

      <input type="file" accept="image/*" onChange={handleImage} />

      {/* Original */}
      {original && originalInfo && (
        <div style={{ marginTop: 20 }}>
          <h3>Original Image</h3>
          <img
            src={original}
            alt="original"
            style={{ width: 220, border: "1px solid #ccc" }}
          />
          <p><strong>Size:</strong> {originalInfo.size}</p>
          <p>
            <strong>Resolution:</strong>{" "}
            {originalInfo.dim.width} x {originalInfo.dim.height}
          </p>
          <p><strong>Format:</strong> {originalInfo.type}</p>
        </div>
      )}

      {/* Results */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 20,
          marginTop: 30,
        }}
      >
        {results.map((item, index) => {
          let label = "";
          let color = "";

          if (item.quality >= 70) {
            label = "Recommended";
            color = "green";
          } else if (item.quality >= 50) {
            label = "Balanced";
            color = "orange";
          } else {
            label = "High Compression";
            color = "red";
          }

          return (
            <div
              key={index}
              style={{
                border: "1px solid #ccc",
                padding: 12,
                width: 250,
                borderRadius: 8,
              }}
            >
              <h4>{item.quality}% Quality</h4>

              <img
                src={item.url}
                alt="compressed"
                style={{ width: "100%", marginBottom: 10 }}
              />

              <p><strong>Size:</strong> {item.size}</p>

              <p>
                <strong>Resolution:</strong>{" "}
                {item.dim.width} x {item.dim.height}
              </p>

              <p><strong>Format:</strong> {item.type}</p>

              <p><strong>Savings:</strong> {item.savings}%</p>

              <p><strong>Time:</strong> {item.time} ms</p>

              <p style={{ color }}>
                <strong>{label}</strong>
              </p>

              <p style={{ fontSize: 12, color: "#666" }}>
                Metadata removed & optimized for web upload
              </p>

              <a href={item.url} download={`compressed_${item.quality}.jpg`}>
                Download
              </a>
            </div>
          );
        })}
      </div>
    </div>
  );
}