import React from "react";
import ImageCompressor from "./components/ImageCompressor";
import OfflineQueue from "./components/OfflineQueue";

function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center" }}>
        Image Compression POC
      </h1>

      <ImageCompressor />
      <hr />
      {/* <OfflineQueue /> */}
    </div>
  );
}

export default App;